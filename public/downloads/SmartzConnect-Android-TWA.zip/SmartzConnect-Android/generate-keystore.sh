#!/usr/bin/env bash
# SmartzConnect Release Keystore Generator
# Run ONCE before your first release. Back up the resulting file securely.
set -e

KEYSTORE="release.keystore"
ALIAS="smartzconnect"

if [ -f "$KEYSTORE" ]; then
  echo "WARNING: $KEYSTORE already exists. Delete it first if you want to regenerate."
  exit 1
fi

keytool -genkeypair -v \
  -keystore "$KEYSTORE" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=SmartzConnect, OU=Mobile, O=SmartzConnect Ltd, L=Lagos, ST=Lagos, C=NG"

echo ""
echo "Keystore created: $KEYSTORE"
echo ""
echo "--- Your SHA-256 fingerprint (paste into .well-known/assetlinks.json) ---"
keytool -list -v -keystore "$KEYSTORE" -alias "$ALIAS" | grep "SHA256:" | awk '{print $2}'
echo ""
echo "NEXT STEPS:"
echo "  1. Back up $KEYSTORE — it cannot be recovered."
echo "  2. Update app/build.gradle signingConfigs.release."
echo "  3. Deploy .well-known/assetlinks.json to your production domain."
