# SmartzConnect — Android TWA Package

A **Trusted Web Activity (TWA)** project that wraps your SmartzConnect PWA
in a native Android shell — no duplicate codebase needed.

---

## Prerequisites

| Tool | Version | Download |
|------|---------|----------|
| Android Studio | Hedgehog+ | [developer.android.com/studio](https://developer.android.com/studio) |
| JDK | 17+ | Bundled with Android Studio |
| Android SDK | API 34 | Via Android Studio SDK Manager |

---

## Step 1 — Open the project

1. Launch **Android Studio**
2. **File → Open** → select this folder
3. Wait for Gradle sync to complete (~first run downloads dependencies)

---

## Step 2 — Replace icon files

Copy your production icon PNG files into:

```
app/src/main/res/mipmap-hdpi/ic_launcher.png        (72×72)
app/src/main/res/mipmap-mdpi/ic_launcher.png         (48×48)
app/src/main/res/mipmap-xhdpi/ic_launcher.png        (96×96)
app/src/main/res/mipmap-xxhdpi/ic_launcher.png      (144×144)
app/src/main/res/mipmap-xxxhdpi/ic_launcher.png     (192×192)
```

Add `ic_launcher_round.png` at the same sizes for circular icons.

---

## Step 3 — Update your domain

Edit `app/src/main/res/values/strings.xml`:

```xml
<string name="launchUrl">https://YOUR-DOMAIN.com/app/feed</string>
<string name="assetLinksHost">YOUR-DOMAIN.com</string>
```

---

## Step 4 — Generate your signing keystore (one-time)

```bash
chmod +x generate-keystore.sh
./generate-keystore.sh
```

Copy the **SHA-256 fingerprint** printed at the end.

---

## Step 5 — Deploy Digital Asset Links

1. Edit `.well-known/assetlinks.json` — paste your SHA-256 fingerprint
2. Deploy it to `https://YOUR-DOMAIN.com/.well-known/assetlinks.json`
   - Must be publicly reachable with `Content-Type: application/json`
   - No redirects allowed on this specific path
3. Verify: https://digitalassetlinks.googleapis.com/v1/statements:list?source.web.site=https://YOUR-DOMAIN.com&relation=delegate_permission/common.handle_all_urls

Without this step the TWA will show a browser URL bar (app still works).

---

## Step 6 — Build

### Debug APK (install directly to device for testing)
**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Output: `app/build/outputs/apk/debug/app-debug.apk`

### Release AAB (required by Google Play)
1. Uncomment `signingConfig signingConfigs.release` in `app/build.gradle`
2. Fill in your keystore path + passwords
3. **Build → Generate Signed Bundle/APK → Android App Bundle**

Output: `app/build/outputs/bundle/release/app-release.aab`

---

## Step 7 — Google Play submission

1. [Google Play Console](https://play.google.com/console) → Create app
2. Upload your `.aab` to the Internal Testing track first
3. Complete **App content → Content ratings** (IARC questionnaire)
4. Copy the **IARC Certificate ID** → paste into your web `manifest.json` as `iarc_rating_id`
5. Promote to Production when ready

---

## Architecture

```
Native Android shell (TWA)
  └── Chrome Custom Tab (Trusted Web Activity)
        └── Your PWA at https://YOUR-DOMAIN.com
              ├── Service Worker (offline caching + background sync)
              ├── Web Push via OneSignal
              └── All existing PWA features work natively
```
