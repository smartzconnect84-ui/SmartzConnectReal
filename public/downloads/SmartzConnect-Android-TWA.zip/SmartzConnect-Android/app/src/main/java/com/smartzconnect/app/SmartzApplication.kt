package com.smartzconnect.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class SmartzApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            manager.createNotificationChannel(
                NotificationChannel(
                    "smartzconnect_general",
                    "SmartzConnect Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "General app notifications" }
            )

            manager.createNotificationChannel(
                NotificationChannel(
                    "smartzconnect_messages",
                    "Messages",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "New messages and match alerts"
                    enableVibration(true)
                }
            )
        }
    }
}
