import UIKit
import WebKit

class ViewController: UIViewController {

    // ── Configuration ──────────────────────────────────────────────────────
    private let appURL = URL(string: "https://smartzconnect.com/app/feed")!
    private let allowedHosts = ["smartzconnect.com", "www.smartzconnect.com",
                                "app.smartzconnect.com", "cdn.smartzconnect.com"]

    // ── Views ──────────────────────────────────────────────────────────────
    private var webView: WKWebView!
    private let splashView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(red: 0.051, green: 0.039, blue: 0.078, alpha: 1) // #0D0A14
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    private let logoLabel: UILabel = {
        let l = UILabel()
        l.text = "SmartzConnect"
        l.font = .systemFont(ofSize: 28, weight: .bold)
        l.textColor = UIColor(red: 0.925, green: 0.286, blue: 0.600, alpha: 1) // #EC4899
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    private let activityIndicator: UIActivityIndicatorView = {
        let ai = UIActivityIndicatorView(style: .medium)
        ai.color = UIColor(red: 0.925, green: 0.286, blue: 0.600, alpha: 1)
        ai.translatesAutoresizingMaskIntoConstraints = false
        return ai
    }()

    // ── Lifecycle ──────────────────────────────────────────────────────────
    override func viewDidLoad() {
        super.viewDidLoad()
        setupWebView()
        setupSplash()
        loadApp()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    // ── Setup ──────────────────────────────────────────────────────────────
    private func setupWebView() {
        let config = WKWebViewConfiguration()

        // Allow inline media playback (required for video/audio features)
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        // Data store — persistent so auth cookies survive restarts
        config.websiteDataStore = .default()

        // User agent: identifies as SmartzConnect native app
        let wv = WKWebView(frame: .zero, configuration: config)
        wv.customUserAgent = "SmartzConnect-iOS/1.0 Mozilla/5.0"
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.scrollView.bounces = false
        wv.isOpaque = false
        wv.backgroundColor = UIColor(red: 0.051, green: 0.039, blue: 0.078, alpha: 1)
        wv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(wv)

        NSLayoutConstraint.activate([
            wv.topAnchor.constraint(equalTo: view.topAnchor),
            wv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            wv.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        webView = wv
    }

    private func setupSplash() {
        view.addSubview(splashView)
        splashView.addSubview(logoLabel)
        splashView.addSubview(activityIndicator)

        NSLayoutConstraint.activate([
            splashView.topAnchor.constraint(equalTo: view.topAnchor),
            splashView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            splashView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            splashView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            logoLabel.centerXAnchor.constraint(equalTo: splashView.centerXAnchor),
            logoLabel.centerYAnchor.constraint(equalTo: splashView.centerYAnchor),

            activityIndicator.centerXAnchor.constraint(equalTo: splashView.centerXAnchor),
            activityIndicator.topAnchor.constraint(equalTo: logoLabel.bottomAnchor, constant: 24),
        ])
        activityIndicator.startAnimating()
    }

    private func loadApp() {
        var request = URLRequest(url: appURL)
        request.cachePolicy = .useProtocolCachePolicy
        webView.load(request)
    }

    private func hideSplash() {
        UIView.animate(withDuration: 0.4, delay: 0.3, options: .curveEaseOut) {
            self.splashView.alpha = 0
        } completion: { _ in
            self.splashView.removeFromSuperview()
        }
    }
}

// ── WKNavigationDelegate ───────────────────────────────────────────────────
extension ViewController: WKNavigationDelegate {

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        hideSplash()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        hideSplash()
        showOfflineMessage()
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let host = navigationAction.request.url?.host else {
            decisionHandler(.allow)
            return
        }
        // Keep navigation within the allowed hosts; open external links in Safari
        if allowedHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) {
            decisionHandler(.allow)
        } else {
            if let url = navigationAction.request.url {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
        }
    }

    private func showOfflineMessage() {
        let html = """
        <!DOCTYPE html><html><body style="
          background:#0D0A14;color:#fff;font-family:system-ui;
          display:flex;flex-direction:column;align-items:center;
          justify-content:center;height:100vh;margin:0;text-align:center;padding:2rem;">
          <h1 style="color:#EC4899;font-size:2rem;margin-bottom:1rem">SmartzConnect</h1>
          <p style="opacity:.7;font-size:1.1rem">You appear to be offline.<br>
          Please check your connection and try again.</p>
          <button onclick="window.location.reload()" style="
            margin-top:2rem;background:#EC4899;color:#fff;border:none;
            padding:0.8rem 2rem;border-radius:2rem;font-size:1rem;cursor:pointer;">
            Retry
          </button>
        </body></html>
        """
        webView.loadHTMLString(html, baseURL: appURL)
    }
}

// ── WKUIDelegate (file upload, camera, alerts) ─────────────────────────────
extension ViewController: WKUIDelegate {

    // Allow camera/microphone access for the web app
    func webView(
        _ webView: WKWebView,
        requestMediaCapturePermissionFor origin: WKSecurityOrigin,
        initiatedByFrame frame: WKFrameInfo,
        type: WKMediaCaptureType,
        decisionHandler: @escaping (WKPermissionDecision) -> Void
    ) {
        decisionHandler(.grant)
    }

    // Pass JS alerts/confirms through to native UI
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: "SmartzConnect", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }
}
