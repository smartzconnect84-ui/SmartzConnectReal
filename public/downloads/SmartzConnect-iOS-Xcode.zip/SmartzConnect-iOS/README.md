# SmartzConnect — iOS Package

A native **WKWebView** iOS app that loads your SmartzConnect PWA.
All your existing web features work natively where supported by WKWebView — camera,
location, media upload, and the branded offline state.

---

## Requirements

| Tool | Version |
|------|---------|
| macOS | Ventura 13+ |
| Xcode | 15+ |
| Apple Developer Account | Required for device testing & App Store |

> **Linux/Windows users:** iOS builds require Apple hardware. This is an
> Apple platform constraint, not a Replit limitation. Use a Mac or a
> macOS cloud VM (e.g. MacStadium, AWS EC2 Mac) to build.

---

## Step 1 — Open in Xcode

1. Double-click `SmartzConnect.xcodeproj`
2. Xcode opens the project automatically

---

## Step 2 — Update your domain

In `ViewController.swift` line 9, replace with your production URL:

```swift
private let appURL = URL(string: "https://smartzconnect.com/app/feed")!
private let allowedHosts = ["smartzconnect.com", "www.smartzconnect.com",
                                "app.smartzconnect.com", "cdn.smartzconnect.com"]
```

---

## Step 3 — Add your app icons

Replace placeholder entries in:
`SmartzConnect/Assets.xcassets/AppIcon.appiconset/`

Required sizes (add all of them):
- 1024×1024 (App Store)
- 180×180, 120×120, 87×87, 60×60, 58×58, 40×40, 29×29, 20×20

Use [appicon.co](https://www.appicon.co) to generate all sizes from one 1024px PNG.

---

## Step 4 — Configure signing

1. Click the **SmartzConnect** project in the navigator
2. Select the **SmartzConnect** target → **Signing & Capabilities**
3. Set **Team** to your Apple Developer account
4. Xcode will auto-generate a provisioning profile

---

## Step 5 — Add Associated Domains (Universal Links)

In **Signing & Capabilities** → **+ Capability** → **Associated Domains**:

```
applinks:smartzconnect.com
applinks:www.smartzconnect.com
```

Then deploy this file to your server:
`https://smartzconnect.com/.well-known/apple-app-site-association`

```json
{
  "applinks": {
    "apps": [],
    "details": [
      {
        "appID": "TEAMID.com.smartzconnect.app",
        "paths": ["/app/*", "/"]
      }
    ]
  }
}
```

Replace `TEAMID` with your 10-character Apple Developer Team ID.

---

## Step 6 — Build & Test

### On Simulator
**Product → Run** (⌘R) — choose any iPhone simulator

### On a physical device
Connect iPhone → select it as the run destination → ⌘R
(Requires free or paid Apple Developer account)

---

## Step 7 — Archive for App Store

1. **Product → Archive** (device must be selected, not a simulator)
2. In Organizer → **Distribute App → App Store Connect**
3. Follow the upload wizard

---

## Step 8 — App Store Connect submission

1. Go to [App Store Connect](https://appstoreconnect.apple.com)
2. Create a new app with Bundle ID `com.smartzconnect.app`
3. Complete metadata, screenshots (use the ones in `/public/screenshots/`)
4. Submit for review

---

## Features included

| Feature | Implementation |
|---------|---------------|
| Full-screen PWA | WKWebView, no address bar |
| Push notifications | Web push where supported by the installed iOS version |
| Camera & microphone | Native permission prompts wired to web API |
| Photo library | Native picker available to `<input type=file>` |
| Location | Native CLLocationManager via WKWebView APIs |
| Offline page | Custom branded offline HTML when network fails |
| Biometrics | Not declared until a native Face ID flow is implemented |
| Universal Links | Deep-link into specific app routes |
| External links | Opened in Safari, not inside the app |
| Badge count | Cleared on foreground |
